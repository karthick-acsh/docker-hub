# Name of Issue
Description of Issue

- ActionHero Version: `x.x.x`
- Node.js Version: `x.x.x`
- Operating System: `(OSX, Ubuntu 14, Windows 10, etc)`

# Steps to reproduce your error
- Make a new actionhero project with `npx actionhero generate`
- create an action with the following content...

---

If your "issue" does not fit into this template, it might not be an issue!  Please join our [slack team](http://slack.actionherojs.com) and ask the question of the community.  We can help!
